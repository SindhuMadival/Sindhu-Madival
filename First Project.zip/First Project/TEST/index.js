const button = document.getElementById("cart-btn");
        const cart = document.getElementById('cart')
        let i = 1;
        button.addEventListener("click", () => {
            cart.innerText = i++;
        })