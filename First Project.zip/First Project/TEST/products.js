// DUMMY PRODUCTS (PRODUCT ID : DATA)
var products = {
  123: {
    name : "Veet",
    desc : "Hair removal cream and stripes.",
    img : "veet.jpg",
    price : 20
  },
  124: {
    name : "Nivea",
    desc : "Body Lotion.",
    img : "nevia.jfif",
    price : 15
  },
  125: {
    name : "Nivea Lipcare",
    desc : "Lip-Balm.",
    img : "vaseline.jfif",
    price : 10
  },
  126: {
    name : "Pantene",
    desc : "Shampoo and conditioner. ",
    img : "shampoo.jpeg",
    price : 20
  }
};