var btn=document.getElementById("btn")
const name=document.getElementById("firstname")
function fname() {
    if(firstname.value==''){
        alert("First name is required")
    }
    if(lastname.value==''){
    alert("last name is required")
    }
    if(Adress.value==''){
        alert("Adress is required")
    }
    if(password.value==''){
    alert("Enter Password")
    }
    if(lastname.value!='' && firstname.value!="" && Adress.value !='') {
    alert("Your response has been recorded")
    }

}
btn.addEventListener("click",fname); 